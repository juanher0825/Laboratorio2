package CustomizedException;

public class OddNumberException extends Exception {
    public OddNumberException (String msg) {
        super(msg);
    }
}